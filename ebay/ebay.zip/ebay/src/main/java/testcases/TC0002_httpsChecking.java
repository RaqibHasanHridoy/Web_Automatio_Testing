package testcases;

import org.testng.annotations.Test;
import base.driversetup;

public class TC0002_httpsChecking extends driversetup{
	static String baseurl ="https://www.ebay.com/";
	@Test(priority=2)
	public static void isWebSiteSecured() {
		String url=driver.getCurrentUrl();
		
		if (url.contains("https")) {
			System.out.println("Site is secured");
		}else {
			System.out.println("Site is not secured");
		}
	}

}