package objectmodels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P0003_Exploreoptions {
	WebDriver driver = null;

	public P0003_Exploreoptions(WebDriver driver) {

		this.driver = driver;

	}
	 By Popular_brands=By.xpath("//body/div[@id='mainContent']/div[@id='destinations_list1']/div[1]/div[1]/div[2]/a[1]");
	 By Popular_categories=By.xpath("//body/div[@id='mainContent']/div[@id='destinations_list2']/div[1]/div[1]/div[2]/a[1]");
	 By Daily_deals=By.xpath("//a[@aria-label='See All Deals']");
	 
	 
	 
	 public void Popular_brands () {
			driver.findElement(Popular_brands).click();
		}
	 public void Popular_categories () {
			driver.findElement(Popular_categories).click();
		}
	 public void Daily_deals () {
			driver.findElement(Daily_deals).click();
		}
	 
	



























}
