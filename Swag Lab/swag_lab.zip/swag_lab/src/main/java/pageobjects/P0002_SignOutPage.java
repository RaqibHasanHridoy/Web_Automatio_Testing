package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P0002_SignOutPage {
	WebDriver driver = null;

	public P0002_SignOutPage(WebDriver driver) {

		this.driver = driver;
		}

	By burger_menu_btn=By.id("react-burger-menu-btn");
	By logout_sidebar_link=By.id("logout_sidebar_link");
	
	public void burger_menu_btn() {
		driver.findElement(burger_menu_btn).click();
	}
	public void logout_sidebar_link() {
		driver.findElement(logout_sidebar_link).click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
