package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P0003_CartAndOrder {
	WebDriver driver = null;

	public P0003_CartAndOrder(WebDriver driver) {

		this.driver = driver;
		}
	
	By bagtocart =By.id("add-to-cart-sauce-labs-backpack");
	By shopping_cart_link=By.className("shopping_cart_link");
	By checkout=By.id("checkout");
	By first_name=By.id("first-name");
	By lastname=By.id("last-name");
	By postalcode=By.id("postal-code");
	By continuebutton=By.id("continue");
	By finish=By.id("finish");
	By back_to_products=By.id("back-to-products");
	
	public void bagtocart() {
		driver.findElement(bagtocart).click();
	}
	public void shopping_cart_link() {
		driver.findElement(shopping_cart_link).click();
	}
	public void checkout() {
		driver.findElement(checkout).click();
	}
	public void first_name() {
		driver.findElement(first_name).sendKeys("Mr.");
	}
	public void lastname() {
		driver.findElement(lastname).sendKeys("Brown");
	}
	public void postalcode() {
		driver.findElement(postalcode).sendKeys("6440");
	}
	public void continuebutton() {
		driver.findElement(continuebutton).click();
	}
	public void finish() {
		driver.findElement(finish).click();
	}
	public void back_to_products() {
		driver.findElement(back_to_products).click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
