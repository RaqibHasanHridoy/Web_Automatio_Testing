package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P0001_SignInPage {
	WebDriver driver = null;

	public P0001_SignInPage(WebDriver driver) {

		this.driver = driver;
}
	By username=By.name("user-name");
	By password=By.name("password");
	By loginbutton=By.name("login-button");
	
	public void username() {
		driver.findElement(username).sendKeys("standard_user");
	}
	public void password() {
		driver.findElement(password).sendKeys("secret_sauce");
	}
	
	public void loginbutton() {
		driver.findElement(loginbutton).click();
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
