package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.driversetup;
import pageobjects.P0001_SignInPage;

@Test
public class TC0001_LoginAndPageTitleAssertion extends driversetup {
	static String baseurl = "https://www.saucedemo.com/";

	public void testlocation() throws InterruptedException {
		driver.get(baseurl);
		driver.manage().window().maximize();
		P0001_SignInPage signpageobject = new P0001_SignInPage(driver);
		signpageobject.username();
		Thread.sleep(3000);
		signpageobject.password();
		Thread.sleep(3000);
		signpageobject.loginbutton();
		Thread.sleep(3000);
		String foundTitleFromWebsite = driver.getTitle();
		SoftAssert softly = new SoftAssert();
		softly.assertEquals(foundTitleFromWebsite, "Swag Labs");
		softly.assertAll();

	}
}