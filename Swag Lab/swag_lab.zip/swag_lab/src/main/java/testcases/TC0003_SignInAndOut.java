package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.driversetup;
import pageobjects.P0001_SignInPage;
import pageobjects.P0002_SignOutPage;

public class TC0003_SignInAndOut extends driversetup {

	static String baseurl = "https://www.saucedemo.com/";

	@Test
	public void testlocation() throws InterruptedException {
		driver.get(baseurl);
		driver.manage().window().maximize();

		// Sign In
		P0001_SignInPage signpageobject = new P0001_SignInPage(driver);
		signpageobject.username();
		Thread.sleep(3000);
		signpageobject.password();
		Thread.sleep(3000);
		signpageobject.loginbutton();
		Thread.sleep(3000);
		// Sign In Completed

		// Sign Out
		P0002_SignOutPage signoutobject = new P0002_SignOutPage(driver);
		signoutobject.burger_menu_btn();
		Thread.sleep(3000);
		signoutobject.logout_sidebar_link();
		Thread.sleep(3000);
		// Sign Out Completed

	}
}
