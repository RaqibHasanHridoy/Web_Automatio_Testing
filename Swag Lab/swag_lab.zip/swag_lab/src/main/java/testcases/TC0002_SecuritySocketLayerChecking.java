package testcases;

import org.testng.annotations.Test;

import base.driversetup;

public class TC0002_SecuritySocketLayerChecking extends driversetup {
	static String baseurl = "https://www.saucedemo.com/";

	@Test
	public void testlocation() throws InterruptedException {
		driver.get(baseurl);
		driver.manage().window().maximize();

		String url = driver.getCurrentUrl();

		if (url.contains("https")) {
			System.out.println("Site is secured by Security socket layer");
		} else {
			System.out.println("Site is not secured by Security socket layer");
		}

	}
}
