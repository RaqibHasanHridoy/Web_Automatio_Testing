package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import base.driversetup;
import pageobjects.P0001_SignInPage;
import pageobjects.P0002_SignOutPage;
import pageobjects.P0003_CartAndOrder;

public class TC0004_AddToCartAndPlaceOrder extends driversetup {
static String baseurl = "https://www.saucedemo.com/";
	

	@Test
	public void testlocation() throws InterruptedException {
		driver.get(baseurl);
		driver.manage().window().maximize();
		
		//Sign In
		P0001_SignInPage signpageobject = new P0001_SignInPage(driver);
		signpageobject.username();
		Thread.sleep(3000);
		signpageobject.password();
		Thread.sleep(3000);
		signpageobject.loginbutton();
		Thread.sleep(3000);
		//Sign In Completed
		
		//Add to Cart Operation
		P0003_CartAndOrder cartorderobject=new P0003_CartAndOrder(driver);
		cartorderobject.bagtocart();
		Thread.sleep(3000);
		//Bag has been added to cart
		
		//Add to cart -->using drop down value
		WebElement e=driver.findElement(By.className("product_sort_container"));
		Select s = new Select(e);
		Thread.sleep(3000);
		s.selectByValue("lohi");
		Thread.sleep(3000);
		driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).click();
		Thread.sleep(3000);
		//T-shirt has been added to cart
		
		//Go to cart and order them
		cartorderobject.shopping_cart_link();
		Thread.sleep(3000);
		cartorderobject.checkout();
		Thread.sleep(3000);
		cartorderobject.first_name();
		Thread.sleep(3000);
		cartorderobject.lastname();
		Thread.sleep(3000);
		cartorderobject.postalcode();
		Thread.sleep(3000);
		cartorderobject.continuebutton();
		Thread.sleep(3000);
		cartorderobject.finish();
		Thread.sleep(3000);
		cartorderobject.back_to_products();
		Thread.sleep(3000);
		//Order has been placed
		
		
		//Sign Out
		P0002_SignOutPage signoutobject = new P0002_SignOutPage(driver);
		signoutobject.burger_menu_btn();
		Thread.sleep(3000);
		signoutobject.logout_sidebar_link();
		Thread.sleep(3000);
		//Sign Out Completed
}
}
