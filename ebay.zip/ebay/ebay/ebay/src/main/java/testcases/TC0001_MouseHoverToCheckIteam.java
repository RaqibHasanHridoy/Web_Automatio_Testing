package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import base.driversetup;


public class TC0001_MouseHoverToCheckIteam extends driversetup{
	static String baseurl ="https://www.ebay.com/";
	@Test
	public void testlocation() throws InterruptedException{
		driver.get(baseurl);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		
		//Mouse hover over a menu function
		Actions action= new Actions(driver);
	 WebElement element =driver.findElement(By.xpath("//body/div[@id='mainContent']/div[1]/ul[1]/li[3]/a[1]"));  
		action.moveToElement(element).build().perform();
		
		Thread.sleep(5000);
		//Mouse hover continues for sub menu and click it
		WebElement element2=driver.findElement(By.xpath("//a[contains(text(),'Video games and consoles')]")); 
		action.moveToElement(element2);
		action.click().build().perform();
		Thread.sleep(5000);
		//Mouse Hover completed 

}

}

