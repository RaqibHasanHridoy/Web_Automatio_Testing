package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.driversetup;
import objectmodels.P0004_Register;

public class TC0004_Register extends driversetup{
	static String baseurl ="https://www.ebay.com/";
	@Test
	public void testlocation() throws InterruptedException{
		driver.get(baseurl);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		P0004_Register registerobject=new P0004_Register(driver);
		registerobject.register();
		//driver.findElement(By.xpath("//a[text()='register']")).click();
		Thread.sleep(5000);
		
		registerobject.firstname();
		//driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Mr.");
		Thread.sleep(1000);
		
		registerobject.lastname();
		//driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Brown");
		Thread.sleep(1000);
		
		registerobject.Email();
		//driver.findElement(By.xpath("//input[@name='Email']")).sendKeys("Brown@gmail.com");
		Thread.sleep(1000);
		
		registerobject.password();
		//driver.findElement(By.xpath("//input[@name='password']")).sendKeys("12345678raqibhasan");
		Thread.sleep(6000);
		
		registerobject.submit_button();
		//driver.findElement(By.xpath("//button[@id='EMAIL_REG_FORM_SUBMIT']")).click();
		Thread.sleep(5000);

}
}
