package testcases;

import base.driversetup;
import objectmodels.P0003_Exploreoptions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TC0003_exploreEveryOptions extends driversetup{
	static String baseurl ="https://www.ebay.com/";
	@Test
	public void testlocation() throws InterruptedException{
		driver.get(baseurl);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		
		//Exploring Popular Brands
		//driver.findElement(By.xpath("//body/div[@id='mainContent']/div[@id='destinations_list1']/div[1]/div[1]/div[2]/a[1]")).click();
		P0003_Exploreoptions exploreobject=new P0003_Exploreoptions(driver);
		exploreobject.Popular_brands();
		Thread.sleep(3000);
		driver.navigate().back(); //Back to previous page
		Thread.sleep(3000);
		
		//Exploring Popular Categories
		//driver.findElement(By.xpath("//body/div[@id='mainContent']/div[@id='destinations_list2']/div[1]/div[1]/div[2]/a[1]")).click();
		exploreobject.Popular_categories();
		Thread.sleep(3000);
		driver.navigate().back(); //Back to previous page
		Thread.sleep(3000);
		
		
		 //Scroll into specific element
		JavascriptExecutor js = (JavascriptExecutor)driver;    
		WebElement e4=driver.findElement(By.xpath("//a[@aria-label='See All Deals']"));
		js.executeScript("arguments[0].scrollIntoView();",e4);
		Thread.sleep(5000);
		//Scroll into specific element completed
		
		//Daily Deals
		//driver.findElement(By.xpath("//a[@aria-label='See All Deals']")).click();
		exploreobject.Daily_deals();
		Thread.sleep(3000);
		driver.navigate().back(); //Back to previous page
		Thread.sleep(3000);
		
		driver.navigate().refresh();//Refresh button click
		Thread.sleep(3000);
		
		
		
		
		
		
		
		
		
		
		
		
	
	
	}
}
