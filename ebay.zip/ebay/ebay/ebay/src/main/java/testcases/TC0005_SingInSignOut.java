package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import base.driversetup;
import objectmodels.P0005_SignInOut;

public class TC0005_SingInSignOut extends driversetup {
	static String baseurl ="https://www.ebay.com/";
	@Test
	public void testlocation() throws InterruptedException{
		driver.get(baseurl);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		P0005_SignInOut signinoutobject=new P0005_SignInOut(driver);
		signinoutobject.signIn();
		//driver.findElement(By.xpath("//a[text()='Sign in']")).click();
		Thread.sleep(5000);
		
		signinoutobject.userid();
		//driver.findElement(By.xpath("//input[@id='userid']")).sendKeys("raqibhasan36@gmail.com");
		Thread.sleep(6000);
		
		signinoutobject.signincontinuebutton();
		//driver.findElement(By.xpath("//button[@id='signin-continue-btn']")).click();
		Thread.sleep(6000);
		
		signinoutobject.password();
		//driver.findElement(By.xpath("//input[@id='pass']")).sendKeys("cse17104022");
		Thread.sleep(2000);
		
		signinoutobject.signInButton();
		//driver.findElement(By.xpath("//button[@id='sgnBt']")).click();
		Thread.sleep(2000);
		//Sign in Completed
		
		
//		Add to cart operation
//		driver.findElement(By.xpath("//img[@alt='Apple iPad 4 - 4th Generation 9.7\" with Retina Display 16GB WIFI MD510LL/A']")).click();
//		Thread.sleep(6000);
//		driver.findElement(By.xpath("//a[@id='isCartBtn_btn']")).click();
//		Thread.sleep(6000);
//		driver.findElement(By.xpath("//button[@class='call-to-action btn btn--large btn--primary']")).click();
//		Thread.sleep(6000);
		
	   
		//Sign Out process-->Hover function performed
		Actions action= new Actions(driver);
		WebElement element =driver.findElement(By.xpath("//button[@id='gh-ug']"));
		action.moveToElement(element).build().perform();
		Thread.sleep(5000);
		
		WebElement element2=driver.findElement(By.xpath("//a[contains(text(),'Sign out')]")); 
		action.moveToElement(element2);
		action.click().build().perform();
		Thread.sleep(5000);
		//Sign Out completed
		
		
		
		
		

}
}
