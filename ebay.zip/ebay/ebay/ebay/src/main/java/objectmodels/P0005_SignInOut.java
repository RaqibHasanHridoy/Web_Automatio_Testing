package objectmodels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P0005_SignInOut {
	WebDriver driver = null;

	public P0005_SignInOut(WebDriver driver) {

		this.driver = driver;
		}
	By signIn=By.xpath("//a[text()='Sign in']");
	By userid =By.xpath("//input[@id='userid']");
	By signincontinuebutton =By.xpath("//button[@id='signin-continue-btn']");
	By password=By.xpath("//input[@id='pass']");
	By signInButton=By.xpath("//button[@id='sgnBt']");
	
	
	public void signIn() {
		driver.findElement(signIn).click();
	}
	public void userid() {
		driver.findElement(userid).sendKeys("raqibhasan36@gmail.com");
	}
	public void signincontinuebutton() {
		driver.findElement(signincontinuebutton).click();
	}
	public void password() {
		driver.findElement(password).sendKeys("cse17104022");
	}
	public void signInButton() {
		driver.findElement(signInButton).click();
	}
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
