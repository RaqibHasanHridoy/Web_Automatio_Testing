package objectmodels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P0004_Register {
	WebDriver driver = null;

	public P0004_Register(WebDriver driver) {

		this.driver = driver;
	}
	By register=By.xpath("//a[text()='register']");
	By firstname=By.xpath("//input[@name='firstname']");
	By lastname=By.xpath("//input[@name='lastname']");
	By Email=By.xpath("//input[@name='Email']");
	By password=By.xpath("//input[@name='password']");
	By submit_button=By.xpath("//button[@id='EMAIL_REG_FORM_SUBMIT']");
	
	public void register() {
		driver.findElement(register).click();
	}
	public void firstname() {
		driver.findElement(firstname).sendKeys("Mr.");
	}
	public void lastname() {
		driver.findElement(lastname).sendKeys("Brown");
	}
	public void Email() {
		driver.findElement(Email).sendKeys("Brown@gmail.com");
	}
	public void password() {
		driver.findElement(password).sendKeys("12345678raqibhasan");
	}
	public void submit_button() {
		driver.findElement(submit_button).click();
	}
	

























}
